angular.module('SMT').directive('cloudBoxdrive',
        ['$rootScope', '$interval',
            function ($rootScope, $interval) {
                return {
                    restrict: 'AE',
                    replace: true,
                    scope:true,
                    templateUrl: 'app/cloud/cloudBoxdrive.html'
                }
            },
        ]);