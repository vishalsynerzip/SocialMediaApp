angular.module('SMT').directive('cloudDropbox',
        ['$rootScope', '$interval',
            function ($rootScope, $interval) {
                return {
                    restrict: 'AE',
                    replace: true,
                    scope:true,
                    templateUrl: 'app/cloud/cloudDropbox.html'
                }
            },
        ]);