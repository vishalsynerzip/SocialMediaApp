angular.module('SMT').directive('cloudGdrive',
        ['$rootScope', '$interval',
            function ($rootScope, $interval) {
                return {
                    restrict: 'AE',
                    replace: true,
                    scope:true,
                    templateUrl: 'app/cloud/cloudGdrive.html'
                }
            },
        ]);
