angular.module('SMT').controller('cloudCtrl', ['$scope','CloudService','$sce',
function ($scope,cloudService,$sce,$http, $location, host, $analytics) {

    $scope.myname = "test";
    $scope.people={
      "name": "Mr A. Payne",
      "address": {
        "street": "30 Commercial Road",
        "city area/district": "Fratton"
      }
    };
  $scope.configuration={
      "editable": false,
      "viewButtonClass": "btn-info",
      "editButtonClass": "btn-success"
    };
    $scope.options={
      "mode": "code",
      "modes": [
        "tree",
        "form",
        "code",
        "text"
      ],
      "history": false
    };
    //////// Google Drive /////////////////////////////////////////////////////
    $scope.currentFileUrl='';
     $scope.Show=function(control)
     {
        // alert("hi"+id.currentTarget.id);
         $scope.currentFileUrl = $sce.trustAsResourceUrl(control.currentTarget.id);
        // $scope.currentDropboxFileUrl = $sce.trustAsResourceUrl(control.currentTarget.id);
         $scope.$apply();
     }
    
     $scope.oauthToken='';
     $scope.pickerApiLoaded=false;
     $scope.LoginWithGoogle = function() {
            gapi.load('auth', { 'callback': onAuthApiLoad });
            gapi.load('picker', { 'callback': onPickerApiLoad });
        }

        function onAuthApiLoad() {
            window.gapi.auth.authorize(
                {
                    'client_id': '579050972948-ot1hm22tds2oor4m78n3ad9rho9fic0t.apps.googleusercontent.com',
                    'scope': 'https://www.googleapis.com/auth/drive',
                    'immediate': false
                },
                handleAuthResult);
        }

        function onPickerApiLoad() {
            $scope.pickerApiLoaded = true;
            createPicker();
        }

        function handleAuthResult(authResult) {
            if (authResult && !authResult.error) {
                $scope.oauthToken = authResult.access_token;
                createPicker();
            }
        }

        // Create and render a Picker object for picking user Photos.
        function createPicker() {
            if ($scope.pickerApiLoaded && $scope.oauthToken) {
                //var view = new google.picker.View(google.picker.ViewId.DOCS);
                //view.setMimeTypes("application/vnd.openxmlformats-officedocument.presentationml.presentation");
                var picker = new google.picker.PickerBuilder().
                    addView(google.picker.ViewId.DOCS).
                    //addView(view).
                    setOAuthToken($scope.oauthToken).
                    //setDeveloperKey(developerKey).
                    setCallback(pickerCallback).
                    build();
                picker.setVisible(true);
            }
        }

        // A simple callback implementation.
        function pickerCallback(data) {
            var url = 'nothing';
            if (data[google.picker.Response.ACTION] == google.picker.Action.PICKED) {
                var doc = data[google.picker.Response.DOCUMENTS][0];
                cloudService.addDriveFile(doc);
                  $scope.driveFileList = cloudService.driveFileList;
                  $scope.$apply();
            }
            /* var message = 'You picked: ' + url;
             document.getElementById('result').innerHTML = message;*/
        }
        //////////////////////////////////////////////////////////////////////////////////////////
        
        /////////////////////////// DROP-BOX ////////////////////////////////////////////////////
        $scope.ShowDropboxFile=function(control)
    {
        window.open(control.currentTarget.id);
        //$scope.currentDropboxFileUrl = $sce.trustAsResourceUrl(dwnlink);
        //$scope.apply();
    }
    $scope.DownloadFile=function(control)
    {
        var dwnlink = control.currentTarget.name.substr(0, control.currentTarget.name.length - 1) + "1";
        //window.open(control.currentTarget.id);
        $scope.currentDropboxFileUrl = $sce.trustAsResourceUrl(dwnlink);
        //$scope.apply();
         //$scope.currentDropboxFileUrl=$sce.trustAsResourceUrl(control.currentTarget.id);
    }
        
        $scope.LoginWithDropbox=function()
           {
               
              var options = {

    // Required. Called when a user selects an item in the Chooser.
    success: function(files) {
        cloudService.addDropboxFile(files[0]);
        $scope.dropboxFileList = cloudService.dropboxFileList;
        $scope.$apply();
        //alert("Here's the file link: " + files[0].link)
    },

    // Optional. Called when the user closes the dialog without selecting a file
    // and does not include any parameters.
    cancel: function() {

    },

    // Optional. "preview" (default) is a preview link to the document for sharing,
    // "direct" is an expiring link to download the contents of the file. For more
    // information about link types, see Link types below.
    linkType: "preview", // or "direct"

    // Optional. A value of false (default) limits selection to a single file, while
    // true enables multiple file selection.
    multiselect: false, // or true

    // Optional. This is a list of file extensions. If specified, the user will
    // only be able to select files with these extensions. You may also specify
    // file types, such as "video" or "images" in the list. For more information,
    // see File types below. By default, all extensions are allowed.
    //extensions: ['.pdf', '.doc', '.docx'],
};
                  Dropbox.choose(options);
                  
                  
        }
        
        /////////////////////////////////////////////////////////////////////////////////////////
        
        //////////////////////////////////// ONE DRIVE /////////////////////////////////////////
           $scope.ShowOnedriveFile=function(control)
    {
        window.open(control.currentTarget.id);
        //$scope.currentDropboxFileUrl = $sce.trustAsResourceUrl(dwnlink);
        //$scope.apply();
    }
        
         $scope.launchOneDrivePicker=function(){
    var pickerOptions = {
  success: function(files) {
    // Handle returned file object(s)
    //alert("You picked " + files.values[0].fileName);
     cloudService.addoneDriveFile(files.values[0]);
                  $scope.oneDriveFileList = cloudService.oneDriveFileList;
                  $scope.$apply();
  },

  cancel: function() {
      // handle when the user cancels picking a file
  },

  linkType: "webViewLink", // or "downloadLink",
  multiSelect: false // or true
}
    OneDrive.open(pickerOptions);
  }
        
        
        ////////////////////////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////// box drive ////////////////////////////////////////////
        
         $scope.ShowBoxdriveFile=function(control)
     {
        // alert("hi"+id.currentTarget.id);
         window.open(control.currentTarget.id);
        // $scope.currentDropboxFileUrl = $sce.trustAsResourceUrl(control.currentTarget.id);
         //$scope.$apply();
     }
    
        
        
        $scope.boxdrivePicker= function()
        {
           
        var options = {
    clientId: "67s3chcyyak7hl7jpgjkfepm4bol7arp",
    linkType: "shared",
    multiselect: "false"
                        };
var boxSelect = new BoxSelect(options);
 boxSelect.success(function(response) {
     cloudService.addboxDriveFile(response[0]);
                  $scope.boxDriveFileList = cloudService.boxDriveFileList;
                  $scope.$apply();
    console.log(response);
});
// Register a cancel callback handler
boxSelect.cancel(function() {
    console.log("The user clicked cancel or closed the popup");
});
boxSelect.launchPopup();
        }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    ///////////////////////////////////// Amazon Cloud drive //////////////////////////////////////////////
    
    $scope.amazondrivePicker=function(){
        var driveurl = encodeURI("https://www.amazon.com/ap/oa?client_id=amzn1.application-oa2-client.7d9f9ea3481d4603a1eec3a8e0696a6e&scope=clouddrive:Aread_all&response_type=token&redirect_uri=http://localhost:3000/cloud");
         $.get(driveurl, function( data ) {
 alert(data);
               });
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
}]);