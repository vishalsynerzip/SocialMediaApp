angular.module('SMT').directive('cloudOnedrive',
        ['$rootScope', '$interval',
            function ($rootScope, $interval) {
                return {
                    restrict: 'AE',
                    replace: true,
                    scope:true,
                    templateUrl: 'app/cloud/cloudOnedrive.html'
                }
            },
        ]);