angular.module('SMT').directive('cloudAmazondrive',
        ['$rootScope', '$interval',
            function ($rootScope, $interval) {
                return {
                    restrict: 'AE',
                    replace: true,
                    scope:true,
                    templateUrl: 'app/cloud/cloudamazondrive.html'
                }
            },
        ]);